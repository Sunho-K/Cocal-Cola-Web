import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './component/Home';
import TopGnb from './component/TopGnb';
import HamOn from './component/HamOn';
import HeadCarousel from './component/HeadCarousel';
import Content from './component/Content';  


function App() {
  return (
    <Router>
      <div className="App">


        <Switch>

          <Route exact path="/">
            <Home/>

          </Route>

          <Route exact path="/other">
            
            

            

          </Route>



        </Switch>

      </div>
    </Router>
  );
}

export default App;
