import React from 'react';
import '../component.css/HamOn.css'


function HamOn() {
    return(
        <div className='ham_on'>
                    <ul className='content_list'>
                        <li className='content'>Brands</li>
                        <li className='content'>Company</li>
                        <li className='content'>Discover</li>
                        <li className='content'>Impact</li>
                    </ul>
        </div>


    );
}

export default HamOn; 