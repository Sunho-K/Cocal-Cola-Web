import React from "react";
import '../component.css/Content.css'


function content() {
    return(

    <div className="content_wrapper" style={{width: '100%', height: '100%', position: 'relative'}}>
        <div className="content_list">
            <div className="content_first">
                <div className="first_img"/>
                <div style={{left: 137, top: 96, position: 'absolute', color: 'white', fontSize: 40, fontFamily: 'Noto Sans KR', fontWeight: '700', wordWrap: 'break-word'}}>Coca‑Cola System</div>
                <div style={{width: 608, height: 315, left: 137, top: 154, position: 'absolute', color: '#F3F3F3', fontSize: 22, fontFamily: 'Noto Sans', fontWeight: '400', wordWrap: 'break-word'}}>코카-콜라 컴퍼니는 전 세계 보틀링 파트너들과 손을 잡고 비즈니스를 운영하고 있다.<br/>코카-콜라 컴퍼니는 브랜드의 마케팅 전략을 책임지고 있으며, 음료 원액을 보틀링 파트너들에게 판매한다. 보틀링 파트너는 음료 레시피에 맞춰 완제품을 생산하고, 포장 및 판매, 유통을 담당하고 있다.<br/>또한 식료품점, 레스토랑, 편의점, 영화관 등의 고객사들과 긴밀히 협력하여 현지에 맞는 로컬 전략들도 실행한다.<br/>2019년 말 기준 전 세계 225 보틀링 파트너, 900여 개의 보틀링 공장이 있으며, 이를 통해 하루 평균 20억 잔이 판매되고 있다.</div>
            </div>

            <div className="content_second">
                <div style={{width: 1554, height: 565, left: 0, top: 611, position: 'absolute', background: 'linear-gradient(180deg, #9E0120 0%, #BE002C 100%), linear-gradient(270deg, #9C1818 0%, rgba(0, 0, 0, 0) 100%)', boxShadow: '4px 4px 4px rgba(0, 0, 0, 0.05)', borderRadius: 20}} />
                <div style={{left: 811, top: 766, position: 'absolute', color: 'white', fontSize: 40, fontFamily: 'Noto Sans KR', fontWeight: '700', wordWrap: 'break-word'}}>더 나은 미래를 위한 지속가능경영</div>
                <div style={{width: 608, height: 315, left: 811, top: 795, position: 'absolute', color: '#F3F3F3', fontSize: 22, fontFamily: 'Noto Sans', fontWeight: '400', wordWrap: 'break-word'}}>코카-콜라는 더 나은 미래를 위해 지속가능경영도 꾸준히 실천하고 있다. 환경을 생각하고, 지역사회의 경제적 발전을 도우며, 지역사회 구성원들이 행복하고 활기차게 살아갈 수 있도록 지원한다.<br/>지속가능한 패키지(World Without Waste), 깨끗한 물의 환원, 여성 리더십 등 다양한 분야에 걸쳐 전 세계 지역사회에 긍정적인 변화를 이끌어나가고 있다.<br/></div>
            </div>

        </div>
    </div>

    )
}

export default content;