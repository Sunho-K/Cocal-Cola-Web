import React from 'react';
import TopGnb from './TopGnb';
import HamOn from './HamOn'
import HeadCarousel from './HeadCarousel';
import Content from './Content';



function home() {
    return (
        <div>        
            <TopGnb/>
            <HeadCarousel/>
            <Content/>
        </div>

        
    
        
    );
}


export default home;