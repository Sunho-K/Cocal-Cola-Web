import React from 'react';
import '../component.css/Coca.css'



function coca() {
    return (
            <div className="main_backGround" style={{width: '100%', height: '100%', position: 'relative', background: 'white'}}>
            
            <div className='vector_one' style={{width: 588.39, height: 680.81, left: -192, top: 632, position: 'absolute', background: '#DFEAF7'}}>


            </div>
            <div className='vector_two' style={{width: 601.62, height: 502.79, left: 1542, top: -114, position: 'absolute', background: '#3D71F2'}}>
            
            </div>
            <div className='vector_three' style={{width: 405, height: 412, left: 226, top: 844, position: 'absolute', background: '#3D71F2'}}>
            
            </div>

            <img className='sunHo' style={{width: 500, height: 373, left: 204, top: 186, position: 'absolute'}} />
            <div className='sunHo_name' style={{left: 772, top: 286, position: 'absolute', color: 'black', fontSize: 50, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>권순호</div>
            <div className='enJin_name' style={{left: 882, top: 632, position: 'absolute', color: 'black', fontSize: 50, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>김은진</div>
            <div className='sunHo_mail' style={{left: 811, top: 364, position: 'absolute', color: 'black', fontSize: 30, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>ikwonsh303@gmail.com</div>
            <div className='enJin_mail' style={{left: 643, top: 710, position: 'absolute', color: 'black', fontSize: 30, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>kdesign0423@gmail.com</div>
            <div className='sunHo_phoneNum' style={{left: 811, top: 413, position: 'absolute', color: 'black', fontSize: 30, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>010.0000.0000</div>
            <div className='enJin_phoneNum' style={{left: 771, top: 759, position: 'absolute', color: 'black', fontSize: 30, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>010.0000.0000</div>
            <div className='sunHo_information' style={{left: 930, top: 294, position: 'absolute', color: '#A0A0A0', fontSize: 40, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>Sun K</div>
            <div className='enJin_information' style={{left: 736, top: 640, position: 'absolute', color: '#A0A0A0', fontSize: 40, fontFamily: 'Vazirmatn', fontWeight: '400', wordWrap: 'break-word'}}>Silver J</div>
                <img className="sunHo_letter" style={{width: 30, height: 30, left: 772, top: 373, position: 'absolute'}}/>
                <img className="enJin_letter" style={{width: 30, height: 30, left: 990, top: 719, position: 'absolute'}} />
                <img className="sunHo_phone"style={{width: 30, height: 30, left: 772, top: 414, position: 'absolute'}}  />
                <img className='enJin_phone' style={{width: 30, height: 30, left: 990, top: 760, position: 'absolute'}} />
                <img className='enJin' style={{width: 500, height: 500, left: 1021, top: 413, position: 'absolute'}} />
            </div>

            
        
    );
    
}



export default coca;