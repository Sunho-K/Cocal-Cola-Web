import React from 'react';
import '../component.css/HeadCarousel.css'




function headCarousel () {
    return(
        
        <div className='headCarousel_wrapper'>
            <div className='head_carousel'>
                <div className='head_to_left'/> 
                <div className='head_to_right'/>
            </div>

        </div>





    );
    
}

export default headCarousel;