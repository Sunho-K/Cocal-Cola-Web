import React from 'react';
import '../component.css/TopGnb.css'

function TopGnb() {

    // useEffect(() => {

    //     var menu = document.querySelector('.top_menu');

    
    // }, []);

    return (

        <div className="topGnb_wrapper">

            <div className='topGnb_bg'/>

            <span className='top_icon'/>
                
            <div  className='top_ham'>
                <div style={{
                    width: 33,
                    height: 3,
                    left: 0,
                    top: 11.23,
                    position: 'absolute',
                    background: '#D9D9D9',
                    borderRadius: 20}}
                    />

                <div style={{
                    width: 33,
                    height: 3,
                    left: 0,
                    top: 0,
                    position:'absolute',
                    background: '#D9D9D9',
                    borderRadius: 20}}
                    />
                </div>
                    
                    
                {/* <span className='ham_on'>
                    <ul className='content_list'>
                        <li className='content'><a href='#'>Brands</a></li>
                        <li className='content'><a href='#'>Company</a></li>
                        <li className='content'><a href='#'>Discover</a></li>
                        <li className='content'><a href='#'>Impact</a></li>
                    </ul>
                </span> */}

        </div>
        
        

        



    );
}    




export default TopGnb;