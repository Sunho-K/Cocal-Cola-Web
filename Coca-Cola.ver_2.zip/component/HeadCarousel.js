import React from 'react';
import '../component.css/HeadCarousel.css'




function headCarousel () {
    return(
        

        // 이곳은 헤드 캐러셀의 이벤트 담당 부문입니다.
        // 왼쪽 오른쪽 버튼을 누를시 해당하는 이벤트 페이지가 헤드 케러셀로 이동합고 기존에 있던 캐러셀은 밀려납니다.

        <div className='headCarousel_wrapper'>
            <div className='head_carousel'>
                <div className='head_to_left'/> 
                <div className='head_to_right'/>
            </div>

        
            <div className='side_event_one'>

            </div>

            <div className='side_event_two'>

            </div>

        </div>





    );
    
}

export default headCarousel;